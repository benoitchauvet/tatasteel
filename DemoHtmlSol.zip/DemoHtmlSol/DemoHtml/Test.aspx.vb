﻿Public Class Test
    Inherits System.Web.UI.Page

    'Code behind

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim nom As String
        Dim prenom As String

        txtPrenom.CssClass = "toto"

        ' récupération de données en GET :
        Dim a As String = Request.QueryString("nom")

        'récupération de données en POST :
        Dim b As String = Request.Form("nom")

        'récupération de données en GET ou POST
        nom = Request("nom")
        prenom = Request("prenom")

        lblMessage.Text = "Bonjour " + nom + " " + prenom


    End Sub

End Class