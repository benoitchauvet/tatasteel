﻿Public Class Accueil
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        'Dim motDePasse As String = "admin"
        'Dim toto As Object = Nothing
        'toto.ToString()


    End Sub

End Class