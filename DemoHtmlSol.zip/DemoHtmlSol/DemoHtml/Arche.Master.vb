﻿Public Class Arche
    Inherits System.Web.UI.MasterPage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Dim m1 As MenuItem = New MenuItem()
            m1.Text = "plop"
            m1.NavigateUrl = "http://www.google.com"

            menuPpal.Items.Add(m1)
        End If

    End Sub

End Class