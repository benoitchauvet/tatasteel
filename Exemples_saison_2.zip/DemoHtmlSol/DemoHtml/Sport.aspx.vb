﻿Public Class Sport
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        GridView1.DataSource = Nothing
        GridView1.DataBind()


    End Sub

End Class