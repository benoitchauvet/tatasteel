﻿Imports System.Web.Services

Public Class DemoWebMethod
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    <WebMethod> _
    Public Shared Function Repondre() As Integer
        Return 42
    End Function


End Class