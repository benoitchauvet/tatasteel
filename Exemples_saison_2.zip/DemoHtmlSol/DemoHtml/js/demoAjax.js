﻿var xhr = new XMLHttpRequest();

// callback :
function traiterReponse() {
    // réponse reçue :
    if (xhr.readyState == 4) {
        // réponse correcte :
        if (xhr.status == 200) {
            var rep = xhr.responseText;

            var personne = JSON.parse(rep);
            console.log(personne.nom + " " + personne.prenom);
        }
        else {
            console.log("probleme... : " + xhr.status);
        }
    }
}

// prépare la requete :
xhr.open('GET', 'Ajax.aspx', true);

// paramétrage de la réception de la réponse :
xhr.onreadystatechange = traiterReponse;

// envoyer la requete :
xhr.send();