// ajouter un élément :

var nouvelle = document.createElement("option");

nouvelle.value = "42";
nouvelle.classList.toggle("nv");
nouvelle.innerHTML = "Je suis la nouvelle option";

var liste = document.querySelector("#maListe");

liste.appendChild(nouvelle);

// parcours et édition d'éléments :

var pairs = document.querySelectorAll("option:nth-child(even)");
for (var i = 0; i < pairs.length; i++)
  {
    var o = pairs[i];
    o.style.backgroundColor = "yellow";
  }


var options = document.getElementsByTagName("option");

for (var i = 0; i < options.length; i++)
  {
    var opt = options[i];
    opt.innerHTML = "plop" + i;
    opt.value = "gnagngna";
    //opt.style = "background:hotpink;";
    opt.classList.toggle("toto");
  }

