﻿'use strict';

// Number
var n = "toto";
console.log(n);
n = Number(n);

n = undefined;

if (!isNaN(n)) {
    console.log(n);
}

// Text
var s = 'toto';
s = "plop";
var w = 4;
//w = "hello";
//w = true;
console.log(w);

var x = 2;

if (3 == x) {
    console.log(x);
}
else {
    console.log("n'importe quoi");
}

console.log(x = 2);
console.log(2 == "2"); // true
console.log(2 === "2"); // false

direBonjour();

function direBonjour() {

    console.log("hello world");
}