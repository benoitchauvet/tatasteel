﻿// gestion des événements :

window.onkeypress = gererOptin;

var optin = document.getElementById("chkOptin");

optin.onclick = gererOptin;
// equivaut à :
// optin.addEventListener("click", gererOptin);

// AVEC FONCTIONS ANONYMES :

//optin.onclick = function(){
//    console.log("je suis dans une fonction anonyme");
//};

//optin.addEventListener("click", function () {
//    console.log("je suis dans une fonction anonyme");
//});


function gererOptin(e) {
    console.log(e);
    // afficher/masquer textbox email
    console.log("youhou");
}