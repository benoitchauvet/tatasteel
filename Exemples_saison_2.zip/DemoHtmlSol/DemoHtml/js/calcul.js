﻿function additionner(a, b)
{
    if (arguments.length != 2)
    {
        throw new Error("La fonction additionner attend 2 paramètres !");
    }

    if (!b)
    {
        b = 0;
    }
    return a + b;
}

function somme()
{
    // arguments : liste des valeurs reçues en paramètres

    var total = 0;

    for (var i = 0; i < arguments.length; i++)
    {
        var n = arguments[i];
        if (! isNaN(n))
        {
            total += Number(n);
        }
    }

    return total;
}