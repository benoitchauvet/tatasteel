﻿var club =
    [
        {
            nom: "hendrix",
            prenom: "jimi",
            adresse: {
                ligne: "lkjkjlkj",
                ville: "new york"
            }
        },
        {
            nom: "cobain",
            prenom: "kurt",
            adresse: {
                ligne: "pennyroyal lane",
                ville: "seatle"
            }
        }
    ]
    
var strClub = JSON.stringify(club);

var objClub = JSON.parse(strClub);

console.log(strClub);