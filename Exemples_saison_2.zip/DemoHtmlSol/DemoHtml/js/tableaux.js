﻿function testerTableaux()
{
    // tableaux indicés :
    var tab = new Array();
    tab.push("printemps");
    tab.push("été");
    tab.push("automne");
    tab.push("hiver");

    //tab.length = 4;

    console.log(tab.join());
    console.log(tab.length);
}