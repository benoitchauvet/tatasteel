﻿Public Class Arche
    Inherits System.Web.UI.MasterPage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Me.Page.User.Identity.IsAuthenticated Then
            lblUser.Text = "Bonjour " + Me.Page.User.Identity.Name
            lblUser.Visible = True
            btnLogout.Visible = True
            lnkLogin.Visible = False
        Else
            lblUser.Visible = False
            btnLogout.Visible = False
            lnkLogin.Visible = True
        End If


        If Not IsPostBack Then
            Dim m1 As MenuItem = New MenuItem()
            m1.Text = "plop"
            m1.NavigateUrl = "http://www.google.com"

            'menuPpal.Items.Add(m1)
        End If
    End Sub

    Protected Overrides Sub OnPreRender(e As EventArgs)
        MyBase.OnPreRender(e)

        If Request.Cookies("coul") IsNot Nothing Then
            bodyArche.Style.Add("background", Request.Cookies("coul").Value)
        End If

    End Sub

    Protected Sub btnLogout_Click(sender As Object, e As EventArgs)
        'deconnexion
        FormsAuthentication.SignOut()
        FormsAuthentication.RedirectToLoginPage()
    End Sub
End Class