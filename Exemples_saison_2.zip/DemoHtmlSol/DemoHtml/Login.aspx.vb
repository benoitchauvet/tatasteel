﻿Public Class Login
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'txtLogin.Text = Request.LogonUserIdentity.Name
    End Sub

    Protected Sub btnLogin_Click(sender As Object, e As EventArgs)

        If txtLogin.Text = "admin" And txtPassword.Text = "admin" Then
            FormsAuthentication.RedirectFromLoginPage(txtLogin.Text, False)
        End If

    End Sub
End Class