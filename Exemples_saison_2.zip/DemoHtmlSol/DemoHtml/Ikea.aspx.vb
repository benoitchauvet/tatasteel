﻿Public Class Ikea
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        lblMessage.Text = "hello"

        If Not IsPostBack Then
            btnOk.Text = "plop"
            txtNom.Text = "votre nom..."
        End If

    End Sub

    Protected Sub btnOk_Click(sender As Object, e As EventArgs) Handles btnOk.Click
        lblMessage.Text = txtNom.Text
    End Sub

    Protected Overrides Sub OnPreRender(e As EventArgs)
        MyBase.OnPreRender(e)
        'Response.Write("youpi !")
        Response.StatusCode = 418
    End Sub

    Protected Overrides Sub Render(writer As HtmlTextWriter)
        MyBase.Render(writer)

        'Response.ContentType = "text/xml"
        'Response.Write("<?xml version='1.0' encoding='UTF-8'?>")
        'Response.Write("<toto>")

        'Response.Write("<titi>jslkfjlkdsj</titi>")

        'Response.Write("</toto>")


    End Sub


End Class