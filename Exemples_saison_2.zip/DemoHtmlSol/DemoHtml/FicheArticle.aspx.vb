﻿Imports System.Data.SqlClient


Public Class FicheArticle
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        ' récupération de l'identifiant :
        Dim idArticle As Integer

        idArticle = CInt(Request("id"))

        Dim cnx As New SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings("MagasinConnectionString").ConnectionString)

        Dim cmd As New SqlCommand()

        cmd.CommandText = "SELECT * FROM Article WHERE id = @id"
        cmd.Parameters.Add(New SqlParameter("@id", idArticle))
        cmd.Connection = cnx

        cnx.Open()

        Dim dr As SqlDataReader = cmd.ExecuteReader()

        If dr.Read() Then
            lblLibelle.Text = dr("libelle")
            lblDescription.Text = dr("description")
            lblPrix.Text = String.Format("{0:c}", dr("prix"))
        End If

        cnx.Close()


    End Sub

End Class