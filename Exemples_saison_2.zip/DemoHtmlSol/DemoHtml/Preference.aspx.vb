﻿Public Class Preference
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            If Request.Cookies("coul") IsNot Nothing Then
                txtCouleur.Value = Request.Cookies("coul").Value
            End If
        End If

    End Sub

    Protected Sub btnOk_Click(sender As Object, e As EventArgs)
        Dim couleur As String = txtCouleur.Value

        Dim cookie As HttpCookie = new HttpCookie("coul")
        cookie.Value = couleur
        cookie.HttpOnly = true
        cookie.Expires = DateTime.Now.AddDays(7)

        Response.Cookies.Add(cookie)
        Response.Redirect("Preference.aspx")

    End Sub
End Class