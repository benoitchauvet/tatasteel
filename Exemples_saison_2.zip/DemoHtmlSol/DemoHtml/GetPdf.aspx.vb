﻿Imports System.IO

Public Class GetPdf
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim contenu As Byte() = File.ReadAllBytes(Server.MapPath("test.pdf"))

        'recuperation du Byte() dans BO


        Response.BinaryWrite(contenu)
        
        Response.ContentType = "application/pdf"

    End Sub

End Class