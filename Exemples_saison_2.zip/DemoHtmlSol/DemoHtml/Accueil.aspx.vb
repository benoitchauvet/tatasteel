﻿Public Class Accueil
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        'Dim motDePasse As String = "admin"
        'Dim toto As Object = Nothing
        'toto.ToString()

        Dim cookie As HttpCookie = New HttpCookie("secret")
        cookie.Value = "C'était pas du poulet..."
        cookie.HttpOnly = True
        cookie.Expires = DateTime.Now.AddDays(3)

        Response.Cookies.Add(cookie)

    End Sub

End Class