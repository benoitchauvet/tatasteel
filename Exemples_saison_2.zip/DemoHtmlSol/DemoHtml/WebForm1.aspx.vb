﻿Public Class WebForm1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        For i = 1 To 10

            Dim ligne = New TableRow()

            For j = 1 To 10
                Dim cell = New TableCell()
                cell.Text = i.ToString() + " - " + j.ToString()
                ligne.Cells.Add(cell)
            Next

            Table1.Rows.Add(ligne)
        Next

    End Sub

End Class