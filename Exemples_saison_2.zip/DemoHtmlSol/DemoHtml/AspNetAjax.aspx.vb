﻿Public Class AspNetAjax
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub btnTraduire_Click(sender As Object, e As EventArgs)

        Select Case txtFrancais.Text
            Case "bonjour"
                txtAnglais.Text = "Hello"
            Case "voir clair"
                txtAnglais.Text = "see sharp"
            Case "visuel basique"
                txtAnglais.Text = "visual basic"
            Case Else
                txtAnglais.Text = "too easy"
        End Select

        txtFrancais.Text = ""

    End Sub
End Class