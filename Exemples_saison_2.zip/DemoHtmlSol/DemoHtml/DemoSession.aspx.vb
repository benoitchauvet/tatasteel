﻿Public Class DemoSession
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        lblSession.Text = Request.UserHostAddress
        'ID de la session :
        'Session.SessionID
        'ip du visiteur :
        'Request.UserHostAddress
        'nom de domaine demandé par l'utilisateur :
        'Request.Url.Host

        lblTotal.Text = Application("nbVisiteursTotal")
        lblCourant.Text = Application("nbVisiteursCourant")

        'Session("plop").ToString()
        Dim nb As Integer = CInt(Session("plop"))
        nb += 1
        Session("plop") = nb

        If Request.Cookies("secret") Is Nothing Then
            lblCookie.Text = "C'était du poulet :)"
        Else
            lblCookie.Text = Request.Cookies("secret").Value + " " + Request.Cookies("secret").Expires.ToLongDateString()
        End If

    End Sub

End Class