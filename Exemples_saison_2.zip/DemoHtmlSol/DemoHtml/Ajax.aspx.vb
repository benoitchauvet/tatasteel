﻿Imports System.Web.Services

Public Class Ajax
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Response.Write("{""nom"":""hendrix"",""prenom"":""jimi""}")
        Response.ContentType = "application/json"

    End Sub

    <WebMethod>
    Public Shared Function Repondre() As Integer
        'url : 
        Return 42
    End Function



End Class