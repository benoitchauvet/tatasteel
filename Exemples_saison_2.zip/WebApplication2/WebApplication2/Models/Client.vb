﻿Public Class Client

    Public Sub New(age As Integer, nom As String)
        Me.age = age
        Me.nom = nom
    End Sub


    Public Age As Integer
   
    Public Nom As String
   


End Class
