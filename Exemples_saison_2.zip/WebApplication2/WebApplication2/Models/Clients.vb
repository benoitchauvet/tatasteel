﻿Public Class Clients

    Public Function GetClients()

        Dim liste As New List(Of Client)

        liste.Add(New Client(30, "Amy"))
        liste.Add(New Client(28, "Bob"))
        liste.Add(New Client(42, "Billy"))

        Return liste


    End Function
        
End Class
