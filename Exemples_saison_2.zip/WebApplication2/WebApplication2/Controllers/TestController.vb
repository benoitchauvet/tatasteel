﻿Imports System.Web.Mvc

Namespace Controllers
    Public Class TestController
        Inherits Controller

        ' GET: Test
        Function Index(nom As String, prenom As String) As String
            Return prenom + "  " + nom
        End Function
    End Class
End Namespace