﻿Imports System.Web.Mvc

Namespace Controllers
    Public Class DefaultController
        Inherits Controller

        ' GET: Default
        Function Index(id As Integer?, toto As String) As ActionResult
            'Return "plop " + id.ToString() + toto

            ViewBag.Toto = toto
            ViewBag.nbRepetitions = id

            Return View("Index")

        End Function
    End Class
End Namespace