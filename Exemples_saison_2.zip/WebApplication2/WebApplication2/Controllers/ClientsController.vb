﻿Imports System.Web.Mvc

Namespace Controllers
    Public Class ClientsController
        Inherits Controller

        ' GET: Clients
        Function Liste() As ActionResult

            Dim clients As New Clients()

            ViewData("clts") = clients.GetClients()

            Return View()
        End Function
    End Class
End Namespace